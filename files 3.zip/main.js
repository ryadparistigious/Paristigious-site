  document.getElementById('year').textContent = new Date().getFullYear();

  const heroSlides = document.querySelectorAll('.hero-slide');
  const heroDots = document.querySelectorAll('.hero-dot');
  if (heroSlides.length > 1) {
    let currentSlide = 0;
    const goToSlide = (i) => {
      heroSlides[currentSlide].classList.remove('is-active');
      heroDots[currentSlide]?.classList.remove('is-active');
      currentSlide = i;
      heroSlides[currentSlide].classList.add('is-active');
      heroDots[currentSlide]?.classList.add('is-active');
    };
    heroDots.forEach((dot, i) => dot.addEventListener('click', () => goToSlide(i)));
    setInterval(() => goToSlide((currentSlide + 1) % heroSlides.length), 6000);
  }

  const header = document.getElementById('siteHeader');
  window.addEventListener('scroll', () => {
    header.classList.toggle('scrolled', window.scrollY > 40);
  });

  const burger = document.getElementById('burger');
  const navLinks = document.getElementById('navLinks');
  burger.addEventListener('click', () => {
    const open = navLinks.style.display === 'flex';
    navLinks.style.display = open ? 'none' : 'flex';
    navLinks.classList.toggle('menu-open', !open);
    navLinks.style.flexDirection = 'column';
    navLinks.style.position = 'absolute';
    navLinks.style.top = '100%';
    navLinks.style.left = '0';
    navLinks.style.right = '0';
    navLinks.style.background = 'rgba(246,242,233,0.98)';
    navLinks.style.padding = '1.5rem 6%';
    navLinks.style.gap = '1.2rem';
  });

  const revealEls = document.querySelectorAll('.reveal');
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('in'); });
  }, { threshold: 0.15 });
  revealEls.forEach(el => io.observe(el));

  const serviceTrack = document.getElementById('serviceTrack');
  if (serviceTrack) {
    const serviceSlides = Array.from(serviceTrack.querySelectorAll('.service-slide'));
    const slideCurrentEl = document.getElementById('slideCurrent');
    const prevBtn = document.getElementById('prevSlide');
    const nextBtn = document.getElementById('nextSlide');
    let current = 0;

    const getSlideWidths = () => {
      const w = window.innerWidth;
      if (w <= 640) return { base: 70, active: Math.min(340, w * 0.84) };
      if (w <= 900) return { base: 140, active: Math.min(440, w * 0.8) };
      return { base: 220, active: Math.min(440, w * 0.8) };
    };

    const renderCarousel = () => {
      serviceSlides.forEach((s, i) => s.classList.toggle('is-active', i === current));
      slideCurrentEl.textContent = current + 1;
      const containerWidth = serviceTrack.parentElement.offsetWidth;
      const gap = parseFloat(getComputedStyle(serviceTrack).gap) || 0;
      const { base, active } = getSlideWidths();
      let offset = 0;
      for (let i = 0; i < current; i++) {
        offset += base + gap;
      }
      offset += active / 2;
      const translate = containerWidth / 2 - offset;
      serviceTrack.style.transform = `translateX(${translate}px)`;
    };

    const goTo = (i) => {
      current = (i + serviceSlides.length) % serviceSlides.length;
      renderCarousel();
    };

    prevBtn.addEventListener('click', () => goTo(current - 1));
    nextBtn.addEventListener('click', () => goTo(current + 1));
    serviceSlides.forEach((slide, i) => {
      slide.addEventListener('click', () => {
        if (i === current) {
          const href = slide.dataset.href;
          if (href) window.location.href = href;
        } else {
          goTo(i);
        }
      });
    });
    window.addEventListener('resize', renderCarousel);
    renderCarousel();
  }

  const form = document.getElementById('quoteForm');
  const note = document.getElementById('formNote');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      note.textContent = 'Demande enregistrée — nous revenons vers vous sous 24h.';
      note.style.color = '#D9BD8C';
      form.reset();
    });
  }

  const partnerForm = document.getElementById('partnerForm');
  const partnerNote = document.getElementById('partnerFormNote');
  if (partnerForm) {
    partnerForm.addEventListener('submit', (e) => {
      e.preventDefault();
      partnerNote.textContent = 'Demande enregistrée — nous revenons vers vous sous 24h.';
      partnerNote.style.color = '#D9BD8C';
      partnerForm.reset();
    });
  }
